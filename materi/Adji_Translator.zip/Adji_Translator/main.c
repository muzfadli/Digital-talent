#include "link-includes.h"
#define MAXINPUT 1024

/*int fget_input_string(char *input_string, FILE *in, FILE *out) {
    if (fgets(input_string, MAXINPUT, in)) return 1;
    else return 0;
}
*/
int main() {

    Dictionary		dict;
    Parse_Options	opts;
    Sentence		sent;
    Linkage			linkage;
    char *			diagram;
    int				i, k, num_linkages;
    char *			input_string[] = {"I am here and you are there.",
	"I saw a pretty small white girl."};
	char *			l_label;
	char *			r_label;
	   
	opts = parse_options_create();
	dict = dictionary_create("4.0.dict", "4.0.knowledge", NULL, "4.0.affix");
	
	for (i=0; i<2; ++i) {
		sent = sentence_create(input_string[i], dict);
		num_linkages = sentence_parse(sent, opts);
		if (num_linkages > 0) {
			linkage = linkage_create(0, sent, opts);
			printf("%s\n", diagram = linkage_print_diagram(linkage));
			string_delete(diagram);
			printf("\nLink Label = \n");
			for (k=1; k<sentence_length(sent)-1; ++k) {
				l_label = linkage_get_link_llabel(linkage, k);
				r_label = linkage_get_link_rlabel(linkage, k+1);
				printf("word-%d left and right label = %s %s\n", k, l_label, r_label);
			}
			linkage_delete(linkage);
		}
		sentence_delete(sent);
	}
	dictionary_delete(dict);
	parse_options_delete(opts);
	return 0;
}