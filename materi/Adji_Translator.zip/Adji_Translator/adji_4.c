/********************************************************************************/
/* Copyright (c) 2004                                                           */
/* Daniel Sleator, David Temperley, and John Lafferty                           */
/* All rights reserved                                                          */
/*                                                                              */
/* Use of the link grammar parsing system is subject to the terms of the        */
/* Apache-style license set forth in the LICENSE file included with this        */ 
/* software, and also available at http://www.link.cs.cmu.edu/link/license.html */
/* This license allows free redistribution and use in source and binary forms,  */
/* with or without modification, subject to certain conditions.                 */
/*                                                                              */
/********************************************************************************/


 /****************************************************************************
 *  
 *   This is a version of the parser for use on the WWW.  
 *   Special properties:
 *      - no prompt
 *      - limit space and memory
 *      - limit link length
 *      - allows !mark to break up output
 *      - displays all or one linkage 
 *        (to demonstrate API)
 *     
 ****************************************************************************/

#include "link-includes.h"

#define MAXINPUT 1024
#define DISPLAY_MAX 100
#define COMMENT_CHAR '%'  /* input lines beginning with this are ignored */

#define DICTIONARY "4.0.dict"  
   /* the path of the dictionary is used to lookup the following files and the word files */
#define AFFIX_FILE "4.0.affix"
#define PP_KNOWLEDGE "4.0.knowledge"
#define CONS_KNOWLEDGE "4.0.constituent-knowledge"


static int display_all;
static int max_sentence_length;
static int min_short_sent_len=20;
static int use_postscript = 0;   /* this is obsolete, but I'll leave it here */
char *	   chosen_words[MAX_SENTENCE];
char	   adji_disjunct[MAX_SENTENCE];


int fget_input_string(char *input_string, FILE *in) {
    if (fgets(input_string, MAXINPUT, in)) return 1; // gets is flexible, input can be from keyboard or file
    else return 0;
}

// ADJI
void process_first_linkage(Sentence sent, Parse_Options opts) {
    char * string;
    int   	mode;
    Linkage	linkage;	// ADJI

	
	linkage = linkage_create(0, sent, opts);	// ADJI
	linkage_compute_union(linkage); // ADJI
	linkage_set_current_sublinkage(linkage, linkage_get_num_sublinkages(linkage));

	fprintf(stdout, "Lingkage:\n");
	if (parse_options_get_display_on(opts)) {
		if (use_postscript) {
		string = linkage_print_postscript(linkage, 0);
		} else {
		string = linkage_print_diagram(linkage);
		}
		fprintf(stdout, "%s", string);
		string_delete(string);
	}

    if ((mode=parse_options_get_display_constituents(opts))) {
	if (mode == 1) {
	    fprintf(stdout, "Constituent tree:\n\n");
	} else if (mode == 2) {
	    fprintf(stdout, "Constituent tree in bracked form:\n\n");
	}
	string = linkage_print_constituent_tree(linkage, mode);
	fprintf(stdout, "%s\n", string);
	string_delete(string);
    }
	linkage_delete(linkage);
}

int special_command(char *input_string, Parse_Options opts, Dictionary dict) {

    if (input_string[0] == '\n') return TRUE;
    if (input_string[0] == COMMENT_CHAR) return TRUE;
    if (input_string[0] == '!') {
	input_string[strlen(input_string)-1] = '\0';
	if (strncmp("!mark", input_string, 5) == 0) {
	    fprintf(stdout, "mark: %s\n", input_string+6);
	    fflush(stdout);
	}
	else if (strncmp("!null=", input_string,6)==0) {
	    parse_options_set_allow_null(opts, atoi(input_string+6));
	}
	else if (strncmp("!justone=", input_string,9)==0) {
	    display_all = atoi(input_string+9) > 0 ? FALSE : TRUE;
	}
	else if (strncmp("!use-postscript=", input_string,16)==0) {
	    use_postscript = (atoi(input_string+16) != 0);
	}
	else if (strncmp("!constituents=", input_string,14)==0) {
 	    parse_options_set_display_constituents(opts, atoi(input_string+14));
	}
	else if (strncmp("!link-display=", input_string,14)==0) {
	    parse_options_set_display_on(opts, atoi(input_string+14));
	}
	return TRUE;
    }
    return FALSE;
}

void setup_www_features(Parse_Options opts) {
    max_sentence_length = 70;
    parse_options_set_max_parse_time(opts, 10);
    parse_options_set_max_memory(opts, 128000000);
}

void setup_panic_parse_options(Parse_Options opts) {
    parse_options_set_disjunct_cost(opts, 3);
    parse_options_set_min_null_count(opts, 1);
    parse_options_set_max_null_count(opts, MAX_SENTENCE);
    parse_options_set_max_parse_time(opts, 60);
    parse_options_set_islands_ok(opts, 1);
    parse_options_set_short_length(opts, 6);
    parse_options_set_all_short_connectors(opts, 1);
    parse_options_set_linkage_limit(opts, 100);
}

int main(int argc, char * argv[]) {

    Dictionary      dict;
    Parse_Options   opts, panic_parse_opts;
    Sentence        sent;
    int             num_linkages;
    char            input_string[MAXINPUT];
    int             reported_leak, dictionary_and_option_space;
	int				i, j;	//	ADJI

    if (argc != 1) {
        fprintf(stderr, "Usage: %s\n", argv[0]);
		exit(-1);
    }

    opts = parse_options_create();
    if (opts == NULL) {
		fprintf(stderr, "%s\n", lperrmsg);
		exit(-1);
    }
    panic_parse_opts = parse_options_create();
    if (panic_parse_opts == NULL) {
		fprintf(stderr, "%s\n", lperrmsg);
		exit(-1);
    }
    setup_panic_parse_options(panic_parse_opts);
    parse_options_set_panic_mode(opts, TRUE);

    dict = dictionary_create(DICTIONARY, PP_KNOWLEDGE, CONS_KNOWLEDGE, AFFIX_FILE);
    if (dict == NULL) {
		fprintf(stderr, "%s\n", lperrmsg);
		exit(-1);
    }

    dictionary_and_option_space = space_in_use;  
    reported_leak = external_space_in_use = 0;

    setup_www_features(opts);

	char choice;
    do {
		fflush(stdin);
		printf("Input sentence = ");
		gets(input_string);
//		fget_input_string(input_string, stdin); //stdin is from keyboard
		if (space_in_use != dictionary_and_option_space + reported_leak) {
			fprintf(stderr, "Warning: %d bytes of space leaked.\n",
				space_in_use-dictionary_and_option_space-reported_leak);
			reported_leak = space_in_use - dictionary_and_option_space;
		}
		if (special_command(input_string, opts, dict)) continue;
		sent = sentence_create(input_string, dict);
		if (sentence_length(sent) > max_sentence_length) {
			sentence_delete(sent);
			fprintf(stdout, "Sentence length (%d words) exceeds " \
				"maximum allowable (%d words)\n",
		    sentence_length(sent), max_sentence_length);
			continue;
		}
		if (sentence_length(sent) > min_short_sent_len) {
			parse_options_set_short_length(opts, 6);
		}
		else {
			parse_options_set_short_length(opts, max_sentence_length);
		}
		/* First parse with cost 0, 1 or 2 and no null links */
		parse_options_set_disjunct_cost(opts, 2);
		parse_options_set_min_null_count(opts, 0);
		parse_options_set_max_null_count(opts, 0);
		parse_options_reset_resources(opts);
		parse_options_set_linkage_limit(opts, 100);
		num_linkages = sentence_parse(sent, opts);
		/* Now parse with null links */
		if ((num_linkages == 0)) {
			fprintf(stdout, "No complete linkages found.\n");
	    if (parse_options_get_allow_null(opts)) {
			parse_options_set_min_null_count(opts, 1);
			parse_options_set_max_null_count(opts, sentence_length(sent));
			num_linkages = sentence_parse(sent, opts);
			}
		}
		if (parse_options_timer_expired(opts)) {
			fprintf(stdout, "Timer is expired!\n");
		}
		if (parse_options_memory_exhausted(opts)) {
			fprintf(stdout, "Memory is exhausted!\n");
		}
		if ((num_linkages == 0) && 
			parse_options_resources_exhausted(opts) &&
			parse_options_get_panic_mode(opts)) {
			fprintf(stdout, "Entering \"panic\" mode...\n");
			parse_options_reset_resources(panic_parse_opts);
			num_linkages = sentence_parse(sent, panic_parse_opts);
		}
		print_total_time(opts);
		// ADJI
		process_first_linkage(sent, opts);
		for (i=1; i<sent->length-1; i++) {
			printf("%10s: \n", chosen_words[i]);
		}
		printf("check-4: %s\n", adji_disjunct);
		j = strlen(adji_disjunct);
		safe_strcpy(adji_disjunct, "", j);
		sentence_delete(sent);
		if (external_space_in_use != 0) {
			fprintf(stderr, "Warning: %d bytes of external space leaked.\n", 
		    external_space_in_use);
		}
		printf("continue? [y/n]");
		scanf("%c", &choice);
    } while (toupper(choice) != 'N');

    parse_options_delete(opts);
    /*    post_process_close(pp);  *DS* */
    dictionary_delete(dict);

    return 0;
}
