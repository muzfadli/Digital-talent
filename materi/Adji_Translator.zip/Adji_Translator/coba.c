#include "link-includes.h"
#define MAXINPUT 1024
#include "stdio.h"

int main() {
	
	Dictionary      dict;
    Parse_Options   opts;
    Sentence        sent;
	Linkage			linkage;
    char *			diagram;
    int             num_linkages;
    char *			input_string[MAXINPUT] = {"You do your homework."}; /*	Define string sufficiently large to 
												store a line of input */
	char *			link_word, show;
	
	//	char cont = 'Y', ch;

	opts = parse_options_create();
	dict = dictionary_create("4.0.dict", "4.0.knowledge", "4.0.constituent-knowledge", "4.0.affix");

/*	
	while (cont == 'Y') {
		printf("Input sentence = \n"); 
		sscanf("%s", input_string);    /* Read line        */

/*		printf("%s", input_string);   */     /* Print line       */
/*		printf("\n");  */    /* Print blank line */

	
		sent = sentence_create(input_string[0], dict);

		num_linkages = sentence_parse(sent, opts);
/*
		if (num_linkages > 0) {
			linkage = linkage_create(0, sent, opts);
			printf("%s\n", diagram = linkage_print_diagram(linkage));
			link_word = linkage_get_word(linkage, 1);
			printf("%s", link_word);
			string_delete(diagram);
			linkage_delete(linkage);

		}
*/
		show = sentence_get_word(sent, 1);
		printf(" %s", show);

		sentence_delete(sent);



	
/*
	printf("continue?[y/n]");
		scanf("%s", &ch);
		cont = toupper(ch);
	}
*/	
	dictionary_delete(dict);
    parse_options_delete(opts);

}

/*
  char another_game = 'Y';

   printf("\nDo you want to play again (y/n)? ");
   scanf("%c", &another_game);

   printf("\n %c ",toupper(another_game));
*/